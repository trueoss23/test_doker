import asyncio
import datetime
import uvicorn
import random
from fastapi import FastAPI
import requests



app = FastAPI()
db = {}
global counter
counter = 0


@app.get("/")
async def get_current_time():
    result1 = requests.get('http://app2:5002/')
    result2 = requests.get('http://214.18.0.20:5002/')
    return {
        "status": "OK",
        "db": db,
        "server1": {
            "status_code": result1.status_code,
            "json": result1.json(),
        },
        "server2": {
            "status_code": result2.status_code,
            "json": result2.json(),
        },

    }


async def send_current_time_count_random_int():
    global counter
    while True:
        current_time = datetime.datetime.now().strftime("%H:%M:%S")
        counter += 1
        random_num = random.randint(1, 100)
        db['current_time'] = current_time
        db['counter'] = counter
        db['random_int'] = random_num
        print(db)
        await asyncio.sleep(5)


@app.on_event("startup")
async def startup_event():
    asyncio.create_task(send_current_time_count_random_int())

